from distutils.core import setup

setup(
    name='alarmserver',
    version='1.0.0',
    packages=['alarmserver'],
    package_data={'alarmserver' : ['doc/*.*']},
    url='',
    license='',
    author='stefanlehmann',
    author_email='mrleeh@gmx.de',
    description=''
)